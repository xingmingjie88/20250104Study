import pandas as pd
import numpy as np
from sklearn.metrics import r2_score, mean_squared_error

# 1⃣ 读取 Excel
file_path = "GRADM.xlsx"
df = pd.read_excel(file_path, sheet_name=0, engine="openpyxl")

# 2⃣ 提取实测值和预测值
y_true = df['SMC'].values
y_pred = df["SMC2"].values  # ⚠️ 请确认预测列名

# 3⃣ 计算 R²
r2 = r2_score(y_true, y_pred)

# 4⃣ 计算 RMSE
rmse = np.sqrt(mean_squared_error(y_true, y_pred))

# 5⃣ 计算 SD（标准差）
sd = np.std(y_true, ddof=1)  # 样本标准差

# 6⃣ 计算 RPD
rpd = sd / rmse

# 7⃣ 输出结果
print(f"R²: {r2:.4f}")
print(f"RMSE: {rmse:.4f}")
print(f"SD: {sd:.4f}")
print(f"RPD: {rpd:.4f}")
